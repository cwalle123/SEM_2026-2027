# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 12:46:39 2024

@author: ruben
"""

import numpy as np
from skimage.measure import find_contours
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from astropy.convolution import AiryDisk2DKernel
from matplotlib import cm
from PIL import Image
from numpy import real,imag
from scipy.signal import convolve2d
import cv2
import time
from WavePSF import calcPSFOTFwave
from functionsBEP import psf_extraction, contours_centroids, contours_centroids_plot, get_bounding_box, lineprofiles, characteristics, aberration_coefficients

# -------------------------- begin program -----------------------------------------------------------------------------------
# simulated wave-optical PSF, excluding Cc
npsf = 1024     #PSF: npsf x npsf pixels          
theta = 0.02    #half opening angle [rad] 
d50geo = 1e-9   #meter
c1 = 2e-7       #meter
a1r = 4e-7;      a1i = 7e-7
b2r = 0.2e-6;    b2i = -0.5e-6;    a2r = 1e-6;    a2i = -1e-6;    c3 = 100e-6

c1 = 2e-9       #meter
a1r = 4e-11;      a1i = 7e-11
b2r = 0.2e-6;    b2i = -0.5e-6;    a2r = 1e-6;    a2i = -1e-6;    c3 = 100e-6
U = 3000;  
zpf = 2   #zero pad factor, ~ 2 to 15 or so
add_noise = False    #Poisson noise
nrParticles = 100   #per pixel, used for Poisson noise

eps = 9.785e-7
Ur = U + eps*(U**2)
lamb = 1.226e-9/Ur**0.5   #electron wavelength
pixsize = 0.5*lamb/(zpf*theta)
print(f"pixel size = {(pixsize*1e9):.3f}  nm")
c1_range = [-5e-7+c1, 5e-7+c1]
t1 = time.perf_counter()
titles = ['Under focus ', 'Over focus ']

aber = (c1_range[0],a1r,a1i,b2r,b2i,a2r,a2i,c3)
aber = np.array(aber)
(psf_u, _) = calcPSFOTFwave(npsf, zpf, lamb, theta, d50geo, aber)   # or (psf, otf) = ...

aber = (c1_range[1],a1r,a1i,b2r,b2i,a2r,a2i,c3)
aber = np.array(aber)
(psf_o, _) = calcPSFOTFwave(npsf, zpf, lamb, theta, d50geo, aber) 

if (add_noise):
    psf_u = (np.random.poisson(nrParticles*psf_u))/nrParticles
    psf_o = (np.random.poisson(nrParticles*psf_o))/nrParticles
t2 = time.perf_counter()
print(f"calculation time  = {(t2-t1):.3f} sec.")
psf_u = np.fft.fftshift(psf_u);  psf_o = np.fft.fftshift(psf_o) #centered
psf_u = psf_u/np.max(psf_u); psf_o = psf_o/np.max(psf_o)
maximum_psf_u = np.max(psf_u); maximum_psf_o = np.max(psf_o) #check if the psf is normalized
g_u_norm = psf_u; g_o_norm = psf_o
#------------------------------------------Generated psf aberration coefficient calculator before convolution--------------------------------------
r = 4*10**(-9)/pixsize
y,x = psf_u.shape
min_x = int(x/2 - 4*r); max_x = int(x/2 + 4*r)
min_y = int(y/2 - 4*r); max_y = int(y/2 + 4*r)
psf_u = psf_u[min_y:max_y, min_x:max_x] ; psf_o = psf_o[min_y:max_y, min_x:max_x]
psf_u, psf_o, contours_t, centroids_t, max_distance_t = contours_centroids_plot(psf_u, psf_o)
rows_u, cols_u = psf_u.shape; rows_o,cols_o = psf_o.shape
min_length_u = max(rows_u, cols_u); min_length_o = max(rows_o, cols_o)
num_points_u = min_length_u-4; num_points_o = min_length_o-4
num_angles = 40

line_profiles_u_t, angles_u_t, coordinates_u_t, contour_test_u_t = lineprofiles(psf_u, centroids_t[0], contours_t[0], num_angles, num_points_u, max_distance_t)
line_profiles_o_t, angles_o_t, coordinates_o_t, contour_test_o_t = lineprofiles(psf_o, centroids_t[1], contours_t[1], num_angles, num_points_o, max_distance_t)
characteristics_u_t = characteristics(line_profiles_u_t, angles_u_t)
characteristics_o_t = characteristics(line_profiles_o_t, angles_o_t)

C_df_t, A_1_t, B_2_t, A_2_t, C_s_t, S_3_t, A_3_t = aberration_coefficients(characteristics_u_t, characteristics_o_t, angles_u_t)
aber_t = np.array([C_df_t, real(A_1_t), imag(A_1_t), real(B_2_t),imag(B_2_t), real(A_2_t),imag(A_2_t), C_s_t])*pixsize
# Print the results: test aberration coefficients
print("C_df_t: 1st-order defocus")
print("Value:", C_df_t*pixsize)
print()
print("A1_t: 1st-order astigmatism")
print("Value:", A_1_t*pixsize)
print()
print("B2_t: 2nd-order coma")
print("Value:", B_2_t*pixsize)
print()
print("A2_t: 2nd-order astigmatism")
print("Value:", A_2_t*pixsize)
print()
print("Cs_t: 3rd-order spherical aberration")
print("Value:", C_s_t*pixsize)
print()
print("S3_t: 3rd-order star aberration")
print("Value:", S_3_t*pixsize)
print()
print("A3_t: 3rd-order astigmatism")
print("Value:", A_3_t*pixsize)

#------------------------------------------Aberrated image generator convolver----------------------------------------------------------------------

img_just = Image.open("focus_cropped.tif").convert('L')#just focus
img_just = np.array(img_just)
y_just,x_just = img_just.shape
y_psf, x_psf = g_u_norm.shape
y_crop = int((y_psf-y_just)/2); x_crop = int((x_psf-x_just)/2)
g_u_norm = g_u_norm[y_crop:y_psf-y_crop, x_crop:x_psf-x_crop]
g_o_norm = g_o_norm[y_crop:y_psf-y_crop, x_crop:x_psf-x_crop]
fig, axs = plt.subplots(1,2, figsize = (15,20))
axs[0].imshow(g_u_norm, cmap = 'gray'); axs[1].imshow(g_o_norm, cmap = 'gray')
plt.show()
F = np.fft.fft2(img_just); G_u = np.fft.fft2(g_u_norm); G_o = np.fft.fft2(g_o_norm)
H_u = F*G_u; H_o = F*G_o
fov = 2.6*10**(-6) #field of view

img_under = abs(np.fft.fftshift(np.fft.ifft2(H_u))); img_over = abs(np.fft.fftshift(np.fft.ifft2(H_o)))

fig,axs = plt.subplots(1,3, figsize = (15,20))
axs[0].imshow(img_just, cmap = 'gray'); axs[1].imshow(img_under, cmap = 'gray'); axs[2].imshow(img_over, cmap = 'gray')
plt.show()

#------------------------------------------Aberration retrieval after image convolution-----------------------------------------------------------------
g_u_norm, g_o_norm, r_airy = psf_extraction(img_just, img_under, img_over, fov)

ps = pixsize
rows_u, cols_u = g_u_norm.shape; rows_o,cols_o = g_o_norm.shape
min_length_u = max(rows_u, cols_u); min_length_o = max(rows_o, cols_o)
num_points_u = min_length_u-4; num_points_o = min_length_o-4
num_angles = 40 #number of profile lines

g_u_norm, g_o_norm, contours, centroids, max_distance = contours_centroids_plot(g_u_norm, g_o_norm)
fig, axs = plt.subplots(1, 2, figsize = (15,20))
axs[0].imshow(g_u_norm, cmap="gray"); axs[1].imshow(g_o_norm, cmap = "gray")
axs[0].set_title('Under focus probe profile'); axs[1].set_title('Over focus probe profile')
axs[0].set_xlabel('x [pixels]'); axs[1].set_xlabel('x [pixels]')
axs[0].set_ylabel('y [pixels]')
plt.show()
#profiles
line_profiles_u, angles_u, coordinates_u, contour_test_u = lineprofiles(g_u_norm, centroids[0], contours[0], num_angles, num_points_u, max_distance)
line_profiles_o, angles_o, coordinates_o, contour_test_o = lineprofiles(g_o_norm, centroids[1], contours[1], num_angles, num_points_o, max_distance)

#line profiles
line_profiles_u_xy = np.array(line_profiles_u).T
line_profiles_o_xy = np.array(line_profiles_o).T
x_u,y_u = line_profiles_u_xy; x_o, y_o = line_profiles_o_xy

#contour check
Cu = []; Co = []
for t in np.arange(len(contour_test_u)):
    lineprof_u = contour_test_u[t]
    lineprof_o = contour_test_o[t]
    for l in np.arange(len(lineprof_u)):
        if lineprof_u[l][0] == 1:
            Cu.append(lineprof_u[l][1])
        else:
            continue
    for l in np.arange(len(lineprof_o)):
        if lineprof_o[l][0] == 1:
            Co.append(lineprof_o[l][1])
        else:
            continue
xu_C = [x[0] for x in Cu]; yu_C = [x[1] for x in Cu]
xo_C = [x[0] for x in Co]; yo_C = [x[1] for x in Co]

fig,axs = plt.subplots(1, 2, figsize =(15,20))
axs[0].set_ylabel('y [pixels]'); axs[0].set_xlabel('x [pixels]'); axs[1].set_xlabel('x [pixels]')
axs[0].set_title('Under focus probe profile with ' + str(num_angles) + ' profile lines')
axs[1].set_title('Over focus probe profile with ' + str(num_angles) + ' profile lines')
axs[0].imshow(g_u_norm, cmap = 'gray'); axs[1].imshow(g_o_norm, cmap = 'gray')
axs[0].plot(xu_C, yu_C, 'r'); axs[0].plot(contours[0][:,1], contours[0][:,0], 'r-')
axs[1].plot(xo_C, yo_C, 'r'); axs[1].plot(contours[1][:,1], contours[1][:,0], 'r-')
plt.show()
#characteristics
characteristics_u = characteristics(line_profiles_u, angles_u)
characteristics_o = characteristics(line_profiles_o, angles_o)

#aberration coefficients
C_df, A_1, B_2, A_2, C_s, S_3, A_3 = aberration_coefficients(characteristics_u, characteristics_o, angles_u)
aber_deconv = np.array([C_df, real(A_1), imag(A_1), real(B_2), imag(B_2), real(A_2), imag(A_2), C_s])*ps
# Print the results
print("C_df: 1st-order defocus")
print("Value:", C_df*ps)
print()
print("A1: 1st-order astigmatism")
print("Value:", A_1*ps)
print()
print("B2: 2nd-order coma")
print("Value:", B_2*ps)
print()
print("A2: 2nd-order astigmatism")
print("Value:", A_2*ps)
print()
print("Cs: 3rd-order spherical aberration")
print("Value:", C_s*ps)
print()
print("S3: 3rd-order star aberration")
print("Value:", S_3*ps)
print()
print("A3: 3rd-order astigmatism")
print("Value:", A_3*ps)
#---------------------------------------------------Check of the line profiles------------------------------------------------------------
k = 15
num_lines = 4
theta = k*np.pi/num_angles
steps = int(num_angles/num_lines)
#line profile plots
fig, ax = plt.subplots(1,2, figsize=(15,20))
ax[0].imshow(g_u_norm, cmap = 'gray'); ax[1].imshow(g_o_norm, cmap = 'gray')
fig.tight_layout()
ax[0].set_ylabel('y [pixels]')
for u in np.arange(2):
    ax[u].plot(int(centroids[u][0]), int(centroids[u][1]), 'ro')
    ax[u].plot(contours[u][:,1], contours[u][:,0])
    ax[u].grid(True, linestyle='--', color='b', linewidth=0.5)
    ax[u].set_title(titles[u] + 'probe profile with %i profile lines' %num_lines)
    ax[u].set_xlabel('x [pixels]')

for l in np.arange(num_lines):
    line_coordinates_u = coordinates_u[steps*l]; line_coordinates_o = coordinates_o[steps*l]
    line_x_u = [x[0] for x in line_coordinates_u]; line_y_u = [x[1] for x in line_coordinates_u]
    line_x_o = [x[0] for x in line_coordinates_o]; line_y_o = [x[1] for x in line_coordinates_o]
    ax[0].plot(line_x_u, line_y_u, label = steps*l); ax[1].plot(line_x_o, line_y_o, label = steps*l)
ax[0].legend(title = 'k = '); ax[1].legend(title = 'k = ')
plt.show()
for k in np.arange(num_lines):
    plt.plot(x_u[:,steps*k], y_u[:,steps*k], label = steps*k)
plt.xlabel('j'); plt.ylabel('Normalized intensity')
plt.title(str(num_lines) + ' ' + titles[0] + 'line profiles')
plt.legend(title = 'k = ')
plt.show()

for k in np.arange(num_lines):
    plt.plot(x_o[:,steps*k], y_o[:,steps*k], label = steps*k)
plt.xlabel('j'); plt.ylabel('Normalized intensity')
plt.title(str(num_lines) + ' ' + titles[1] + 'line profiles')
plt.legend(title = 'k = ')
plt.show()