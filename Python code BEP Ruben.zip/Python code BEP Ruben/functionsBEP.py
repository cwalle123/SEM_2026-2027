# -*- coding: utf-8 -*-
"""
Created on Wed May  8 13:15:33 2024

@author: ruben
"""
import numpy as np
from skimage.measure import find_contours
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from astropy.io import fits
from astropy.convolution import AiryDisk2DKernel
import cv2
from numpy import real, imag
from WavePSF import calcPSFOTFwave

def psf_extraction(h,h_u, h_o, fov):
    #psf calculation
    y,x = h.shape #image shape
    ps = fov/x #pixel size
    r_airy = 40*10**(-9)/ps #Airy disk calculation
    g2 = AiryDisk2DKernel(r_airy,x_size = x , y_size = y) #this kernel generates a 2D Airy pattern with radius r_airy
    G2 = np.fft.fft2(g2)
    #fits.writeto('airydisk_kernel_Test.fits', g2.array)                
    H = np.fft.fft2(h); H_u = np.fft.fft2(h_u); H_o = np.fft.fft2(h_o)
    G_u = G2*np.divide(H_u, H); G_o = G2*np.divide(H_o,H)
    #G_u = G2*np.divide(np.conjugate(H_u), np.conjugate(H)); G_o = G2*np.divide(np.conjugate(H_o),np.conjugate(H))
    g_u = np.abs(np.fft.ifft2(G_u)); g_o = np.abs(np.fft.ifft2(G_o)) #absolute value of psf
    #g_u = np.fft.fftshift(g_u); g_o = np.fft.fftshift(g_o)
    g_u_norm = g_u/np.max(g_u); g_o_norm = g_o/np.max(g_o) #normalization
    
    figs,axs = plt.subplots(1,3, figsize = (15,20))
    axs[0].imshow(g2, cmap = 'gray'); axs[1].imshow(g_u_norm, cmap = 'gray'); axs[2].imshow(g_o_norm, cmap = 'gray')
    axs[0].set_title('Just focus probe profile')
    axs[1].set_title('Under focus probe profile')
    axs[2].set_title('Over focus probe profile')
    axs[1].set_xlabel('x [pixels]'); axs[0].set_ylabel('y [pixels]')
    plt.tight_layout()
    plt.show()
    

    #shifting the image to portray the blob in the center
    contours_u = find_contours(g_u_norm, level=0.7)
    contours_o = find_contours(g_o_norm, level=0.7)

    # Get bounding box coordinates for g2_u and g2_o
    min_row_u, min_col_u, max_row_u, max_col_u = get_bounding_box(contours_u)
    min_row_o, min_col_o, max_row_o, max_col_o = get_bounding_box(contours_o)
    #print('min_row_u, min_col_u, max_row_u, max_col_u:',min_row_u, min_col_u, max_row_u, max_col_u)
    #print('min_row_o, min_col_o, max_row_o, max_col_o:',min_row_o, min_col_o, max_row_o, max_col_o)

        # Calculate translation for h2_u
    center_u = ((min_row_u + max_row_u) // 2, (min_col_u + max_col_u) // 2)
    translation_u = (g_u_norm.shape[0] // 2 - center_u[0], g_u_norm.shape[1] // 2 - center_u[1])
    
    # Calculate translation for h2_o
    center_o = ((min_row_o + max_row_o) // 2, (min_col_o + max_col_o) // 2)
    translation_o = (g_o_norm.shape[0] // 2 - center_o[0], g_o_norm.shape[1] // 2 - center_o[1])
    
    # Apply translation to both images
    rows_u, cols_u = g_u_norm.shape
    M_u = np.float32([[1, 0, translation_u[1]], [0, 1, translation_u[0]]])
    g_u_norm = cv2.warpAffine(g_u_norm, M_u, (cols_u, rows_u))
    
    rows_o, cols_o = g_o_norm.shape
    M_o = np.float32([[1, 0, translation_o[1]], [0, 1, translation_o[0]]])
    g_o_norm = cv2.warpAffine(g_o_norm, M_o, (cols_o, rows_o))
    
    figs,axs = plt.subplots(1,3, figsize = (15,20))
    axs[0].imshow(g2, cmap = 'gray'); axs[1].imshow(g_u_norm, cmap = 'gray'); axs[2].imshow(g_o_norm, cmap = 'gray')
    axs[0].set_title('Just focus probe profile')
    axs[1].set_title('Under focus probe profile')
    axs[2].set_title('Over focus probe profile')
    axs[1].set_xlabel('x [pixels]'); axs[0].set_ylabel('y [pixels]')
    plt.tight_layout()
    plt.show()
    
    #cropping
    min_x = int(x/2 - 4*r_airy); max_x = int(x/2 + 4*r_airy)
    min_y = int(y/2 - 4*r_airy); max_y = int(y/2 + 4*r_airy)
    g_u_norm = g_u_norm[min_y:max_y, min_x:max_x]; g_o_norm = g_o_norm[min_y:max_y, min_x:max_x]
    

    #plots
    fig, axes = plt.subplots(1,3, figsize = (15,20))    
    g2_image = mpimg.imread('Airydisk_Alitest.png') #I cheated here, couldn't get the kernel to zoom in on the spot so I created an image of the Airy pattern
    g2_image = g2_image[min_y:max_y , min_x:max_x]
    axes[0].imshow(g2_image, cmap = 'gray')
    axes[1].imshow(g_u_norm, cmap = 'gray', interpolation = 'None'); axes[2].imshow(g_o_norm, cmap = 'gray', interpolation = 'None')
    axes[1].set_title('Under focus probe profile'); axes[2].set_title('Over focus probe profile'); axes[0].set_title('Just focus probe profile')
    axes[1].set_xlabel('x [pixels]'); axes[0].set_ylabel('y [pixels]')
    #axes[1].set_xlabel('x [pixels]'); axes[1].set_ylabel('y [pixels]')
    
    plt.show()
    return g_u_norm, g_o_norm, r_airy

def contours_centroids_plot(g_u_norm, g_o_norm):
    #contour
    contours = []
    contour_u1 = find_contours(g_u_norm, level = 0.2) 
    contour_o1 = find_contours(g_o_norm, level = 0.2)
    contour_u = contour_u1[0]; contours.append(contour_u) 
    contour_o = contour_o1[0]; contours.append(contour_o)
    
    #centroid
    centroids = []
    centroid_up = np.mean(contour_u, axis=0)
    centroid_u = [centroid_up[1], centroid_up[0]]; centroids.append(centroid_u)
    centroid_op = np.mean(contour_o, axis=0)
    centroid_o = [centroid_op[1], centroid_op[0]]; centroids.append(centroid_o)
    
    # Calculate max distance for both contours
    max_distance_u = max(g_u_norm.shape[0] - centroid_u[0], g_u_norm.shape[1] - centroid_u[1])
    max_distance_o = max(g_o_norm.shape[0] - centroid_o[0], g_o_norm.shape[1] - centroid_o[1])
    max_distance = max(max_distance_u, max_distance_o)

    # Display the image and plot all contours found
    fig, ax = plt.subplots(1,2)
    ax[0].imshow(g_u_norm, cmap='gray')
    ax[1].imshow(g_o_norm, cmap='gray')
    #fig.tight_layout()
    ax[0].set_title('Under focus probe profile')
    ax[1].set_title('Over focus probe profile')
    ax[0].set_xlabel('x [pixels]'); ax[0].set_ylabel('y [pixels]')
    ax[1].set_xlabel('x [pixels]'); ax[1].set_ylabel('y [pixels]')
    
    # Plot contours
    ax[0].plot(contour_u[:, 1], contour_u[:, 0])
    ax[1].plot(contour_o[:, 1], contour_o[:, 0])
    
    # Plot centroid as a red dot
    ax[0].plot(centroid_u[0], centroid_u[1], 'ro')
    ax[0].plot()
    ax[1].plot(centroid_o[0], centroid_o[1], 'ro')
    
    # Add grid lines
    ax[0].grid(True, linestyle='--', color='b', linewidth=0.5)
    ax[1].grid(True, linestyle='--', color='b', linewidth=0.5)
    plt.show()

    return g_u_norm, g_o_norm, contours, centroids, max_distance

def contours_centroids(g_u_norm, g_o_norm):
    #cropping
    y,x = g_u_norm.shape
    min_x = int(x/5); max_x = int(4*x/5)
    min_y = int(y/5); max_y = int(4*y/5)
    g_u_norm = g_u_norm[min_y:max_y, min_x:max_x]; g_o_norm = g_o_norm[min_y:max_y, min_x:max_x]
    #contour
    contours = []
    contour_u1 = find_contours(g_u_norm, level = 0.2) 
    contour_o1 = find_contours(g_o_norm, level = 0.2)
    contour_u = contour_u1[0]; contours.append(contour_u) 
    contour_o = contour_o1[0]; contours.append(contour_o)
    
    #centroid
    centroids = []
    centroid_up = np.mean(contour_u, axis=0)
    centroid_u = [centroid_up[1], centroid_up[0]]; centroids.append(centroid_u)
    centroid_op = np.mean(contour_o, axis=0)
    centroid_o = [centroid_op[1], centroid_op[0]]; centroids.append(centroid_o)
    
    # Calculate max distance for both contours
    max_distance_u = max(g_u_norm.shape[0] - centroid_u[0], g_u_norm.shape[1] - centroid_u[1])
    max_distance_o = max(g_o_norm.shape[0] - centroid_o[0], g_o_norm.shape[1] - centroid_o[1])
    max_distance = max(max_distance_u, max_distance_o)
    return g_u_norm, g_o_norm, contours, centroids, max_distance
def get_bounding_box(contours):
    min_row = min([int(np.min(contour[:, 0])) for contour in contours])
    max_row = max([int(np.max(contour[:, 0])) for contour in contours])
    min_col = min([int(np.min(contour[:, 1])) for contour in contours])
    max_col = max([int(np.max(contour[:, 1])) for contour in contours])
    return min_row, min_col, max_row, max_col

def lineprofiles(image, centroid, contour, num_angles, num_points,max_distance):
    
    #print('centroid point is at:', centroid)
    #print('image shape:', image.shape)
    
    start_point = -num_points // 2 + 2 if num_points % 2 != 0 else -num_points // 2 + 1
    line_profiles = []
    coordinates = []
    contour_test = []
    angles = np.linspace(0, np.pi, num_angles, endpoint=False)
    angles_degrees = np.degrees(angles)
    #print("Angles in degrees:", angles_degrees)
    
    for angle in angles:
        #print('angle (degree):', np.degrees(angle))
        direction_x = np.cos(angle)
        direction_y = np.sin(angle)
        direction_vec = np.array([direction_x, direction_y])
        contour = np.float32(contour) #for the cv2function
        contour_t = []
        line_intensity_with_j = []
        coordinates_angle = []
        for j in range(start_point, num_points//2):
            point_on_line = centroid + j * (max_distance / (num_points // 2)) * direction_vec
            x = np.float32(point_on_line[0])
            y = np.float32(point_on_line[1])
            test = cv2.pointPolygonTest(contour, (y,x), False)# check if the coordinate is inside the contour: +1 if True, -1 if False
            x = int(x); y = int(y) #integer coordinates
            if test == -1:
                intensity = 0
            else:
                intensity = image[x,y]
            contour_t.append((test, (x,y)))
            coordinates_angle.append((x,y))
            line_intensity_with_j.append((j, intensity))
            #print('j:', j, 'x:', x, 'y:', y, 'Intensity:', intensity)
        contour_test.append(contour_t)
        line_profiles.append(line_intensity_with_j)
        coordinates.append(coordinates_angle)
    return line_profiles, angles, coordinates, contour_test

def characteristics(line_profiles, angles):
    line_profiles_sorted = np.array(line_profiles).T
    characteristics_list = []
    for a in np.arange(len(angles)):
        j, p_j = line_profiles_sorted[:,:,a]
        W = np.sum(p_j)
        T = np.sum(p_j**2)
        j0 = np.where(j == 0)[0][0] #check center of the line
        p0 = p_j[j0]
        
        #asymmetry mu
        mu = 1/W * np.sum(j*p_j)
        
        #width sigma standard deviation definition
        #sigma = np.sqrt(1/W* np.sum(j**2*p_j))
        sigma = np.sqrt(1/W * np.sum((j-mu)**2 * p_j))
        
        #curvature rho
        rho_sum = 0
        for ji in j:
            indx = np.where(j == ji)[0][0]
            if ji == 0:
                continue
            else:
                rho_sum += 1/abs(ji)*(p_j[indx]-p0)*p_j[indx]
        rho = sigma**2/T * rho_sum
        characteristics_list.append((sigma, mu, rho))
    return characteristics_list

def aberration_coefficients(characteristics_u, characteristics_o, angles):
    N = len(angles)
    #initial parameters
    C_df = 0
    A_1 = 0
    B_2 = 0
    A_2 = 0
    C_s = 0
    S_3 = 0
    A_3 = 0
    
    for n in np.arange(N):
        sigma_u, mu_u, rho_u = characteristics_u[n]
        sigma_o, mu_o, rho_o = characteristics_o[n]
        
        C_df += (sigma_u - sigma_o)/N
        A_1 += 2*(sigma_u - sigma_o)*np.exp(2j*angles[n])/N
        B_2 += 2*(mu_u + mu_o)*np.exp(1j*angles[n])/N
        A_2 += 2*(mu_u + mu_o)*np.exp(3j*angles[n])/N
        C_s += (rho_u - rho_o)/N
        S_3 += 2*(rho_u - rho_o)*np.exp(2j*angles[n])/N
        A_3 += 2*(sigma_u - sigma_o)*np.exp(4j*angles[n])/N
    return C_df, A_1, B_2, A_2, C_s, S_3, A_3

def coefficient_retrieval_plot(max_factor, ab, nr_angles, waveOTF_param):
    npsf, zpf, lamb, theta, d50geo, pixsize = waveOTF_param
    ab_string = ['C_df','A1_r', 'A1_i', 'B2_r', 'B2_i ', 'A2_r', 'A2_i', 'C3']
    c1, a1r, a1i, b2r, b2i, a2r, a2i, c3 = ab
    c1_range = [-5e-7, 5e-7]
    factor = np.arange(1, max_factor)
    range_coeff_total = []
    range_coeff_deconv_total = []
    for j in np.arange(len(ab)):
        coef = ab[j]
        range_coeff = factor*coef
        range_coeff_deconv = np.zeros(max_factor - 1)
        for i in np.arange(len(factor)):
            #aber_u = np.array([c1_range[0],a1r, a1i, b2r, b2i, a2r, a2i, c3])
            #aber_o = np.array([c1_range[1],a1r, a1i, b2r, b2i, a2r, a2i, c3])
            aber_u = np.array([c1_range[0],0, 0, 0, 0, 0, 0, 0])
            aber_o = np.array([c1_range[1],0, 0, 0, 0, 0, 0, 0])
            aber_u[j] += range_coeff[i]; aber_o[j] += range_coeff[i] #to add defocus
            (psf_u, _) = calcPSFOTFwave(npsf, zpf, lamb, theta, d50geo, aber_u)
            (psf_o, _) = calcPSFOTFwave(npsf, zpf, lamb, theta, d50geo, aber_o)
            aber_u[j] = 0; aber_o[j] = 0 #reset for defocus
            psf_u = np.fft.fftshift(psf_u); psf_o = np.fft.fftshift(psf_o)   #centered   #centered
            g_u_norm = psf_u/np.max(psf_u); g_o_norm = psf_o/np.max(psf_o) #normalized psfs
            
            rows_u, cols_u = g_u_norm.shape; rows_o,cols_o = g_o_norm.shape
            min_length_u = max(rows_u, cols_u); min_length_o = max(rows_o, cols_o)
            num_points_u = min_length_u-4; num_points_o = min_length_o-4
            g_u_norm, g_o_norm, contours, centroids, max_distance = contours_centroids(g_u_norm, g_o_norm)
            
            #profiles
            line_profiles_u, angles_u, coordinates_u, contour_test_u = lineprofiles(g_u_norm, centroids[0], contours[0], nr_angles, num_points_u, max_distance)
            line_profiles_o, angles_o, coordinates_o, contour_test_o = lineprofiles(g_o_norm, centroids[1], contours[1], nr_angles, num_points_o, max_distance)
            #characteristics
            characteristics_u = characteristics(line_profiles_u, angles_u)
            characteristics_o = characteristics(line_profiles_o, angles_o)
            
            C_df, A_1, B_2, A_2, C_s, S_3, A_3 = aberration_coefficients(characteristics_u, characteristics_o, angles_u)
            coef_table = np.array([C_df, real(A_1), imag(A_1), real(B_2), imag(B_2), real(A_2), imag(A_2), C_s])
            range_coeff_deconv[i] += coef_table[j]*pixsize
        print(ab_string[j] + ' simulated', range_coeff)
        print(ab_string[j] + ' retrieved', range_coeff_deconv)
        range_coeff_deconv_total.append(range_coeff_deconv)
        range_coeff_total.append(range_coeff)
        plt.plot(factor, range_coeff_deconv/range_coeff, label = ab_string[j])
    plt.legend()
    plt.xlabel('s (factor)')
    plt.ylabel('Q')
    plt.show()
    return factor, range_coeff_total, range_coeff_deconv_total