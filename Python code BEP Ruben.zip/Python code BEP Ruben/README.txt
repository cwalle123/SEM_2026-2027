README
Python code BEP Ruben

Included in the .zip file are the following py scripts:

functionsBEP: My functions file, including

-psf_extraction: extracts an under and over focus normalized PSFs by generating a 2D Airy pattern and using Fourier analysis. The function also centers (this part I copied from Sarinia's code) and crops the pattern. Returns the cropped PSFs and 
Airy disk radius.

-contours_centroids_plot: traces contours around the probe shapes, calculates their centroids and the maximum distance needed for the line profiles, and plots the contours and centroids alongside the cropped PSFs. Returns the cropped PSFs, contours, centroids and max distance.

-contours_centroids: similar to contours_centroids_plot, but excludes the plot function and includes a cropping function. Returns the cropped PSFs, contours, centroids and max distance.

-get_bounding_box: function I copied from Sarnia's code, used for centering the extracted PSFs

-lineprofiles: draws line profiles through the PSFs. Starts from a point way outside the contour, and iterates through the center to select intensity points. Returns the line profiles, angles of the profiles, the line profile coordinates, and an array to test wheter the points are inside the contour.

-characteristics: calculates the three characteristics used to calculate aberration coefficients. Returns list of characteristics

-aberration_coefficients: calculates aberration coefficients with the characteristics. Returns aberration coefficients

-coefficient_retrieval_plot: generates a range of under and over foucs PSFs with initial aberration coefficients for each of the coefficients discussed in my report. For each PSF, the aberration coefficients are calculated using the functions used above, and from there the ratio between input and output coefficients is calculated and plotted as a function of the factor. Returns the factor array, the input coefficients and the output coefficients.


aberration_calculation_BEP: extracts PSFs and calculates aberration coefficients from a triple of SEM images. It loads the functions from functionsBEP, and includes code that shows the cropped psfs, line profiles.

coefficient_retrieval: Code that calls the coefficient_retrieval_plot, and calculates Q

WavePSF: code Ali shared that generates PSFs\

psf_analysis: Generates PSFs using WavePSF, then calculates aberration coefficients, convolves the PSFs with a test image, and calculates aberration coefficients again.