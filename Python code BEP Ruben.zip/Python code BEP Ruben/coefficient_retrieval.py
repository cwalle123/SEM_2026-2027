# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 18:26:36 2024

@author: ruben
"""

import numpy as np
from skimage.measure import find_contours
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from astropy.convolution import AiryDisk2DKernel
from matplotlib import cm
from PIL import Image
from numpy import real,imag
import cv2
import time
import progressbar
from WavePSF import calcPSFOTFwave
from functionsBEP import psf_extraction, contours_centroids, get_bounding_box, lineprofiles, characteristics, aberration_coefficients, coefficient_retrieval_plot

#------------------------------------------------aberration coefficient retrieval test------------------------------------------------------------------
npsf = 1024     #PSF: npsf x npsf pixels          
theta = 0.02    #half opening angle [rad] 
d50geo = 1e-9   #meter
c1 = 10e-9       #meter
a1r = 2e-9;      a1i = 2e-9
b2r = 20e-9;    b2i = 20e-9;    a2r = 1e-7;    a2i = 1e-7;    c3 = 5e-6
U = 30000;  
zpf = 2   #zero pad factor, ~ 2 to 15 or so
add_noise = False    #Poisson noise
nrParticles = 100   #per pixel, used for Poisson noise

eps = 9.785e-7
Ur = U + eps*(U**2)
lamb = 1.226e-9/Ur**0.5   #electron wavelength
pixsize = 0.5*lamb/(zpf*theta) #This is the pixel size
waveOTF_param = (npsf, zpf, lamb, theta, d50geo, pixsize) #array for ease of input
print(f"pixel size = {(pixsize*1e9):.3f}  nm")
c1_range = [-c1, c1]
max_factor = 51 #S

ab = (c1, a1r, a1i, b2r, b2i, a2r, a2i, c3) #initial coefficients

nr_angles = 40 #number of profile lines with angle theta
#coefficient range
t1 = time.perf_counter()
ab_string = ['C_df','A1_r', 'A1_i', 'B2_r', 'B2_i', 'A2_r', 'A2_i', 'C3']
factor, coeff_range_total, coeff_range_deconv_total = coefficient_retrieval_plot(max_factor, ab, nr_angles, waveOTF_param)
coeff_range_total = np.array(coeff_range_total); coeff_range_deconv_total = np.array(coeff_range_deconv_total)#array conversion
Q = coeff_range_total/coeff_range_deconv_total #ratio between input and retrieved

#-----------------------------------------------plot the ratio Q--------------------------------------------------------------------------------------------
t2 = time.perf_counter()
print(f"calculation time  = {(t2-t1):.3f} sec.")
for i in np.arange(len(coeff_range_total)-1):
    plt.plot(factor, Q[i], label = ab_string[i])
plt.xlabel('s (factor)')
plt.grid(True, linestyle='--', color='b', linewidth=0.5)
plt.ylabel('Q')
plt.legend() 
plt.show()