# -*- coding: utf-8 -*-
"""
Created on Sun May 12 14:01:05 2024

@author: ruben
"""

import numpy as np
from skimage.measure import find_contours
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from astropy.convolution import AiryDisk2DKernel
from matplotlib import cm
from PIL import Image
import cv2
from functionsBEP import psf_extraction, contours_centroids_plot, get_bounding_box, lineprofiles, characteristics, aberration_coefficients
#from aberration_calculation import sigma_u_w, mu_u_w, rho_u_w, sigma_o_w, mu_o_w, rho_o_w

#--------------------------------------------------------------image kernel-------------------------------------------------------------
#UHR_WD7
#img_over = mpimg.imread("UHR_WD7_overfocus.tif")#over focus
#img_under = mpimg.imread("UHR_WD7_underfocus.tif")#under focus
#img_just = mpimg.imread("UHR_WD7_focus.tif")#just focus
#fov = 1.5*10**(-6) #field of view

#Ali test
img_over = mpimg.imread("Ali_test_over_focus.tif")#over focus
img_under = mpimg.imread("Ali_test_under_focus.tif")#under focus
img_just = mpimg.imread("Ali_test_focus.tif")#just focus
fov = 2.6*10**(-6) #field of view

#image1_stig
#img_over = mpimg.imread("image1stig_540.tif")#over focus
#img_under = mpimg.imread("image1stig_000.tif")#under focus
#img_just = mpimg.imread("image1stig_270.tif")#just focus

#generated images
#img_over = Image.open("defocus_C120nm_cropped.tif").convert('L')#over focus
#img_under = Image.open('defocusNeg_C-120nm_cropped.tif').convert('L')#under focus
#img_just = Image.open("focus_cropped.tif").convert('L')#just focus

#plot of the images
img_over = np.array(img_over); img_under = np.array(img_under); img_just = np.array(img_just)
w,l = img_just.shape
ps = fov/l
figs,axs = plt.subplots(1,3, figsize =(15,20))
axs[0].imshow(img_just); axs[1].imshow(img_under); axs[2].imshow(img_over)
plt.tight_layout()
plt.show()

titles = ['Under focus ', 'Over focus '] #title array
#wd = np.array([7.0289, 7.0265, 7.0309])*10**(-3) #working distance table




#r_airy = 0.54*10**(-9)/(15*10**(-3)*ps)
#-----------------------------------------------------PSf extraction and contours---------------------------------------------------
g_u_norm, g_o_norm, r_airy = psf_extraction(img_just, img_under, img_over, fov)
g_u_norm, g_o_norm, contours, centroids, max_distance = contours_centroids_plot(g_u_norm, g_o_norm)

num_angles = 80 #number of profile lines
rows_u, cols_u = g_u_norm.shape; rows_o,cols_o = g_o_norm.shape #shape of the cropped psfs
min_length_u = max(rows_u, cols_u); min_length_o = max(rows_o, cols_o)

num_points_u = min_length_u-4; num_points_o = min_length_o-4 #number of points on the line profiles
print('Number of points on a profile line:', num_points_u)

#-----------------------------------------------------line profiles-----------------------------------------------------------------
line_profiles_u, angles_u, coordinates_u, contour_test_u = lineprofiles(g_u_norm, centroids[0], contours[0], num_angles, num_points_u, max_distance)
line_profiles_o, angles_o, coordinates_o, contour_test_o = lineprofiles(g_o_norm, centroids[1], contours[1], num_angles, num_points_o, max_distance)

#----------------------------------------------------Plot of the lineprofiles inside the contours-------------------------------------
line_profiles_u_xy = np.array(line_profiles_u).T
line_profiles_o_xy = np.array(line_profiles_o).T
x_u,y_u = line_profiles_u_xy; x_o, y_o = line_profiles_o_xy

#contour check, separating points on the line profile in- and outside the contours
Cu = []; Co = []
for t in np.arange(len(contour_test_u)):
    lineprof_u = contour_test_u[t]
    lineprof_o = contour_test_o[t]
    for l in np.arange(len(lineprof_u)):
        if lineprof_u[l][0] == 1:
            Cu.append(lineprof_u[l][1])
        else:
            continue
    for l in np.arange(len(lineprof_o)):
        if lineprof_o[l][0] == 1:
            Co.append(lineprof_o[l][1])
        else:
            continue
xu_C = [x[0] for x in Cu]; yu_C = [x[1] for x in Cu]
xo_C = [x[0] for x in Co]; yo_C = [x[1] for x in Co]

fig,axs = plt.subplots(1, 2, figsize =(15,20))
axs[0].set_ylabel('y [pixels]'); axs[0].set_xlabel('x [pixels]'); axs[1].set_xlabel('x [pixels]')
axs[0].set_title('Under focus probe profile with ' + str(num_angles) + ' profile lines')
axs[1].set_title('Over focus probe profile with ' + str(num_angles) + ' profile lines')
axs[0].imshow(g_u_norm, cmap = 'gray'); axs[1].imshow(g_o_norm, cmap = 'gray')
axs[0].plot(xu_C, yu_C, 'r'); axs[0].plot(contours[0][:,1], contours[0][:,0], 'b-')
axs[1].plot(xo_C, yo_C, 'r'); axs[1].plot(contours[1][:,1], contours[1][:,0], 'b-')
plt.show()
#---------------------------------------------------Check of the line profiles------------------------------------------------------------
k = 15
num_lines = 4
theta = k*np.pi/num_angles
steps = int(num_angles/num_lines)
#line profile plots
fig, ax = plt.subplots(1,2, figsize=(15,20))
ax[0].imshow(g_u_norm, cmap = 'gray'); ax[1].imshow(g_o_norm, cmap = 'gray')
fig.tight_layout()
ax[0].set_ylabel('y [pixels]')
for u in np.arange(2):
    ax[u].plot(int(centroids[u][0]), int(centroids[u][1]), 'ro')
    ax[u].plot(contours[u][:,1], contours[u][:,0])
    ax[u].grid(True, linestyle='--', color='b', linewidth=0.5)
    ax[u].set_title(titles[u] + 'probe profile with %i profile lines' %num_lines)
    ax[u].set_xlabel('x [pixels]')

for l in np.arange(num_lines):
    line_coordinates_u = coordinates_u[steps*l]; line_coordinates_o = coordinates_o[steps*l]
    line_x_u = [x[0] for x in line_coordinates_u]; line_y_u = [x[1] for x in line_coordinates_u]
    line_x_o = [x[0] for x in line_coordinates_o]; line_y_o = [x[1] for x in line_coordinates_o]
    ax[0].plot(line_x_u, line_y_u, label = steps*l); ax[1].plot(line_x_o, line_y_o, label = steps*l)
ax[0].legend(title = 'k = '); ax[1].legend(title = 'k = ')
plt.show()
for k in np.arange(num_lines):
    plt.plot(x_u[:,steps*k], y_u[:,steps*k], label = steps*k)
plt.xlabel('j'); plt.ylabel('Normalized intensity')
plt.title(str(num_lines) + ' ' + titles[0] + 'line profiles')
plt.legend(title = 'k = ')
plt.show()

for k in np.arange(num_lines):
    plt.plot(x_o[:,steps*k], y_o[:,steps*k], label = steps*k)
plt.xlabel('j'); plt.ylabel('Normalized intensity')
plt.title(str(num_lines) + ' ' + titles[1] + 'line profiles')
plt.legend(title = 'k = ')
plt.show()
#----------------------------------------------------characteristics---------------------------------------------------------------------
characteristics_u = characteristics(line_profiles_u, angles_u)
characteristics_o = characteristics(line_profiles_o, angles_o)

#---------------------------------------------------aberration coefficients--------------------------------------------------------------
C_df, A_1, B_2, A_2, C_s, S_3, A_3 = aberration_coefficients(characteristics_u, characteristics_o, angles_u)

# Print the results
print("C_df: 1st-order defocus")
print("Value:", C_df)
print()
print("A1: 1st-order astigmatism")
print("Value:", A_1)
print()
print("B2: 2nd-order coma")
print("Value:", B_2)
print()
print("A2: 2nd-order astigmatism")
print("Value:", A_2)
print()
print("Cs: 3rd-order spherical aberration")
print("Value:", C_s)
print()
print("S3: 3rd-order star aberration")
print("Value:", S_3)
print()
print("A3: 3rd-order astigmatism")
print("Value:", A_3)